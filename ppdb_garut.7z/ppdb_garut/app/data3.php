<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data3 extends Model
{
    protected $table = "data3";
    protected $fillable = ['tbc','malaria','chotipa','cacar','lainnya','jasmani'];

}
