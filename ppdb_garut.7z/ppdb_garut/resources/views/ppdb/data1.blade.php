@extends('../parent.app')
@section('content')
    <form action="/ppdb/data1" method="post">
        {{ csrf_field() }}
        
        <h1><strong>DATA CALON MURID</strong></h1>
        <hr>
    <input type="submit" value="Selanjutnya" class="btn btn-success">

        <hr>
        <div class="form-group">
            <label for="nama"><strong>Nama Lengkap</strong></label>
            <input type="text" id="nama" name="nama_lengkap" class="form-control col-md-5">
            @if($errors->has('nama_lengkap'))
            <h5 class="text-danger">{{ $errors->first('nama_lengkap') }}</h5>
            @endif
        </div>
        <div class="form-group">
            <label for="panggil"><strong>Nama Panggilan</strong></label>
            <input type="text" id="panggil" name="nama_panggilan" class="form-control col-md-5">
            @if($errors->has('nama_panggilan'))
            <h5 class="text-danger">{{ $errors->first('nama_panggilan') }}</h5>
            @endif
        </div>
        <label for=""><strong>Jenis Kelamin</strong></label>
        <div class="custom-control custom-radio">
          <input type="radio" id="ContohRadio1" name="kelamin" value="laki" class="custom-control-input">
          <label class="custom-control-label" for="ContohRadio1">Laki - laki</label>
      </div>
      <div class="custom-control custom-radio">
          <input type="radio" id="ContohRadio2" name="kelamin" value="prempuan" class="custom-control-input">
          <label class="custom-control-label" for="ContohRadio2">Prempuan</label>
          
          @if($errors->has('kelamin'))
          <h5 class="text-danger">{{ $errors->first('kelamin') }}</h5>
          @endif
      </div>
      <br>
      <div class="form-group">
        <label for=""><strong>Tempat,tanggal lahir</strong></label>
        <input type="text" class="form-control col-md-5" name="ttl" placeholder="//bogor,25 november 2002//">
        @if($errors->has('ttl'))
        <h5 class="text-danger">{{ $errors->first('ttl') }}</h5>
        @endif
    </div>
    <div class="form-group">
        <label for="agama"><strong>Agama</strong></label>
        <select name="agama" class="form-control col-md-5" id="agama">
            <option value="">--Pilih Agama--</option>
            <option value="islam">islam</option>
            <option value="kristen">kristen</option>
            <option value="katolik">katolik</option>
            <option value="hindu">hindu</option>
            <option value="buddha">buddha</option>
        </select>
        @if($errors->has('agama'))
        <h5 class="text-danger">{{ $errors->first('agama') }}</h5>
        @endif
    </div>
    <div class="form-group">
        <label for="cita"><strong>cita cita</strong></label>
        <input type="text" class="form-control col-md-5" name="cita" id="cita">
        @if($errors->has('cita'))
        <h5 class="text-danger">{{ $errors->first('cita') }}</h5>
        @endif
    </div>
    <div class="form-group">
        <label for=""><strong>Jumlah saudara</strong></label>
        <br>
        <label for="">kandung</label>
        <input type="number" name="kandung" class="form-control col-md-5" value="0">
        <label for="">tiri</label>
        <input type="number" name="tiri" class="form-control col-md-5" value="0">
        <label for="">angkat</label>
        <input type="number" name="angkat" class="form-control col-md-5" value="0">
    </div>
    <div class="form-group">
        <label for="berat"><strong>Berat badan</strong></label>
        <input type="number" name="berat_badan" class="form-control col-md-5">
        @if($errors->has('berat_badan'))
        <h5 class="text-danger">{{ $errors->first('berat_badan') }}</h5>
        @endif
    </div>
    <div class="form-group">
        <label for="tinggi"><strong>Tinggi badan</strong></label>
        <input type="number" name="tinggi_badan" class="form-control col-md-5">
        @if($errors->has('tinggi_badan')) 
        <h5 class="text-danger">{{ $errors->first('tinggi_badan') }}</h5>
        @endif
    </div>
    <div class="golongan darah">
        <label for=""><strong>Golongan Darah</strong></label>
        <select name="darah" id="" class="form-control col-md-5">
            <option value="">--golongan darah--</option>
            <option value="a">A</option>
            <option value="b">B</option>    
            <option value="ab">AB</option>
            <option value="o">O</option>
        </select>
        @if($errors->has('darah'))
        <h5 class="text-danger">{{ $errors->first('darah') }}</h5>
        @endif
    </div>
    <hr>
</form>
@endsection