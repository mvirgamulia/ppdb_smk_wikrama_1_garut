@extends('../parent.app')
@section('content')
<div class="card">
    <div class="card-header bg-primary">
        <h1><strong>DATA CALON SISWA</strong></h1>
    </div>
    <div class="card-body text-dark">
        @foreach($data1 as $d)
        <strong>id = </strong>{{ $d->id }}<br>
        <strong>nama lengkap = </strong>{{ $d->nama_lengkap }}<br>
        <strong>nama panggilan = </strong>{{ $d->nama_panggilan }}<br>
        <strong>jenis kelamin = </strong>{{ $d->jenis_kelamin }}<br>
        <strong>tempat tanggal lahir = </strong>{{ $d->ttl }}<br>
        <strong>agama = </strong>{{ $d->agama}}<br>
        <strong>cita cita = </strong>{{ $d->cita }}<br>
        <strong>saudara kandung = </strong>{{ $d->kandung }}<br>
        <strong>saudara tiri = </strong>{{ $d->tiri}}<br>
        <strong>saudara angkat = </strong>{{ $d->angkat}}<br>
        <strong>berat badan = </strong>{{$d->berat_badan}}<br>
        <strong>tinggi badan = </strong>{{$d->tinggi_badan}}<br>
        <strong>golongan darah = </strong>{{$d->darah}}<br>
        @endforeach
    </div>
    <div class="card-footer">

    </div>
</div>
<div class="card">
    <div class="card-header bg-warning">
        <h1><strong>ALAMAT TEMPAT TINGGAL</strong></h1>
    </div>
    <div class="card-body text-dark">
        @foreach($data2 as $d)
        <strong>alamat = </strong>{{$d->alamat}}<br>
        <strong>kelurahan = </strong>{{$d->kelurahan}}<br>
        <strong>kecamatan = </strong>{{$d->kecamatan}}<br>
        <strong>kota kabupaten = </strong>{{$d->kotakabupaten}}<br>
        <strong>kode pos = </strong>{{$d->kode_pos}}<br>
        <strong>no telepon = </strong>{{$d->no}}<br>
        <strong>email = </strong>{{$d->email}}<br>
        <strong>tinggal bersama = </strong>{{$d->tinggal}}<br>

        @endforeach
    </div>
    <div class="card-footer">

    </div>
</div>
<div class="card">
    <div class="card-header bg-success">
        <h1><strong>KETERANGAN KESEHATAN</strong></h1>
    </div> 
    <div class="card-body text-dark">
        @foreach($data3 as $d)
        <strong>TBC = </strong>{{ $d->tbc }}<br>
        <strong>malaria = </strong>{{$d->malaria}}<br>
        <strong>chotipa = </strong>{{$d->chotipa}}<br>
        <strong>cacar = </strong>{{$d->cacar}}<br>
        <strong>lainnya = </strong>{{$d->lainnya}}<br>
        <strong>jasmani = </strong>{{$d->jasmani}}<br>
        @endforeach
    </div>
    <div class="card-footer">

    </div>
</div>
<div class="card">
    <div class="card-header bg-danger">
        <h1><strong>DATA ORANG TUA/WALI</strong></h1>
    </div>
    <div class="card-body text-dark">
        @foreach($data4 as $d)
        <strong>nama ayah = </strong>{{$d->nama_ayah}} <br>
        <strong>tempat tanggal lahir = </strong>{{$d->ttl_ayah}} <br>
        <strong>pekerjaan ayah = </strong>{{$d->pekerjaan_ayah}} <br>
        <strong>pendidikan ayah = </strong>{{$d->pendidikan_ayah}}	<br>
        <strong>kewarganegaraan ayah = </strong>{{$d->kewarganegaraan_ayah}} <br>
        <strong>agama ayah = </strong>{{$d->agama_ayah}} <br>
        <strong>no telepon = </strong>{{$d->no_ayah}} <br>
        <hr>
        <strong>nama ibu = </strong>{{$d->nama_ibu}} <br>
        <strong>tempat tanggal lahir = </strong>{{$d->ttl_ibu}} <br>
        <strong>pekerjaan ibu = </strong>{{$d->pekerjaan_ibu}} <br>
        <strong>pendidikan ibu = </strong>{{$d->pendidikan_ibu}} <br>
        <strong>kewarganegaran ibu =</strong>{{$d->kewarganegaraan_ibu}} <br>
        <strong>agama ibu = </strong>{{$d->agama_ibu}} <br>
        <strong>no telepon = </strong>{{$d->no_ibu}}  <br>
        <hr>
        <strong>nama wali = </strong>{{$d->nama_wali}} <br>
        <strong>tempat,tanggal lahir = </strong>{{$d->ttl_wali}}<br>
        <strong>pekerjaan wali = </strong>{{$d->pekerjaan_wali}}<br>
        <strong>pendidikan wali = </strong>{{$d->pendidikan_wali}}	<br>
        <strong>kewarganegaraan wali = </strong>{{$d->kewarganegaraan_wali}}<br>
        <strong>agama wali = </strong>{{$d->agama_wali}}<br>
        <strong>no telepon = </strong>{{$d->no_wali}}<br>
        <strong>hubungan wali = </strong>{{$d->hubungan_wali}}<br>
        <strong>email wali = </strong>{{$d->email_wali}}<br>

        @endforeach
    </div>
    <div class="card-footer">

    </div>
</div>

<table class="table">
    <thead class="bg-dark text-light">
        <tr>
            <td rowspan="2">no</td>
            <td rowspan="2">mata pelajaran</td>
            <td align="center" colspan="2">kelas7</td>
            <td align="center" colspan="2">kelas8</td>
            <td>kelas9</td>
        </tr>
        <tr>
            <td>semester 1</td>
            <td>semester 2</td>
            <td>semester 1</td>
            <td>semester 2</td>
            <td>semester 1</td>
        </tr>
    </thead>
    <tbody class="bg-light">
        @foreach($rapot as $d)
        <tr>
            <td>1</td>
            <td>pai</td>
            <td>{{$d->pai_sm1_7}}</td>
            <td>{{$d->pai_sm2_7}}</td>
            <td>{{$d->pai_sm1_8}}</td>
            <td>{{$d->pai_sm2_8}}</td>
            <td>{{$d->pai_sm1_9}}</td>
        </tr>
        <tr>
            <td>2</td>
            <td>bahasa indonesia</td>
            <td>{{$d->bindo_sm1_7}}</td>
            <td>{{$d->bindo_sm2_7}}</td>
            <td>{{$d->bindo_sm1_8}}</td>
            <td>{{$d->bindo_sm2_8}}</td>
            <td>{{$d->bindo_sm1_9}}</td>
        </tr>
        <tr>
            <td>3</td>
            <td>bahasa inggris</td>
            <td>{{$d->bing_sm1_7}}</td>
            <td>{{$d->bing_sm2_7}}</td>
            <td>{{$d->bing_sm1_8}}</td>
            <td>{{$d->bing_sm2_8}}</td>
            <td>{{$d->bing_sm1_9}}</td>
        </tr>
        <tr>
            <td>4</td>
            <td>matematika</td>
            <td>{{$d->mtk_sm1_7}}</td>
            <td>{{$d->mtk_sm2_7}}</td>
            <td>{{$d->mtk_sm1_8}}</td>
            <td>{{$d->mtk_sm2_8}}</td>
            <td> {{$d->mtk_sm1_9}}</td>
        </tr>
        <tr>
            <td>5</td>
            <td>ipa</td>
            <td> {{$d->ipa_sm1_7}}</td>
            <td>  {{$d->ipa_sm2_7}}</td>
            <td> {{$d->ipa_sm1_8}}</td>
            <td>   {{$d->ipa_sm2_8}}</td>
            <td>  {{$d->ipa_sm1_9}}</td>
        </tr>
        <tr>
            <td>6</td>
            <td>ips</td>
            <td> {{$d->ips_sm1_7}}</td>
            <td>  {{$d->ips_sm2_7}}</td>
            <td>  {{$d->ips_sm1_8}}</td>
            <td>  {{$d->ips_sm2_8}}</td>
            <td>  {{$d->ips_sm1_9}}</td>
        </tr>
        <tr>
            <td>7</td>
            <td>juara</td>
            <td colspan="6"> {{$d->pres }} </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection